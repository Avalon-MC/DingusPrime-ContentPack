onEvent('block.registry', event => {
	event.create('present_wrapped_blue', 'basic').displayName('Present Wrapped Blue').material('wood').defaultCutout().notSolid().noValidSpawns(true).suffocating(false).viewBlocking(false).redstoneConductor(false)
})

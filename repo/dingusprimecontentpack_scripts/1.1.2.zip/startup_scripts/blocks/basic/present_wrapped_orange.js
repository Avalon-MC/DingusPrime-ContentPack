onEvent('block.registry', event => {
	event.create('present_wrapped_orange', 'basic').displayName('Present Wrapped Orange').material('wood').defaultCutout().notSolid().noValidSpawns(true).suffocating(false).viewBlocking(false).redstoneConductor(false)
})

onEvent('block.registry', event => {
	event.create('xmasreef', 'customcardinal').displayName('Xmas Reef').material('wood').lightLevel(14).defaultCutout().noValidSpawns(true).suffocating(false).viewBlocking(false).redstoneConductor(false).box(5, 2, 15, 11, 5, 16, true).box(5, 11, 15, 11, 14, 16, true).box(11, 5, 15, 14, 11, 16, true).box(2, 5, 15, 5, 11, 16, true).box(11, 3, 15, 13, 5, 16, true).box(3, 3, 15, 5, 5, 16, true).box(11, 11, 15, 13, 13, 16, true).box(3, 11, 15, 5, 13, 16, true).box(5, 10, 15, 6, 11, 16, true).box(10, 5, 15, 11, 6, 16, true).box(10, 10, 15, 11, 11, 16, true).box(5, 5, 15, 6, 6, 16, true)
})


onEvent('block.registry', event => {
	event.create('candy_cane_block_blue', 'basic').displayName('Candy Cane Block Blue').material('vegetable').lightLevel(5).defaultCutout().notSolid().noValidSpawns(true).suffocating(false).viewBlocking(false).redstoneConductor(false)
})

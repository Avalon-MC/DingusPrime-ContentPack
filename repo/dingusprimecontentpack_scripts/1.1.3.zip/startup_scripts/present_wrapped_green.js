onEvent('block.registry', event => {
	event.create('present_wrapped_green', 'basic').displayName('Present Wrapped Green').material('wood').defaultCutout().notSolid().noValidSpawns(true).suffocating(false).viewBlocking(false).redstoneConductor(false)
})

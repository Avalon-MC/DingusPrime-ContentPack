onEvent('block.registry', event => {
	event.create('present_wrapped_base', 'basic').displayName('Present Wrapped Red').material('wood').defaultCutout().notSolid().noValidSpawns(true).suffocating(false).viewBlocking(false).redstoneConductor(false).box(2, 0, 2, 14, 9, 14, true).box(1, 9, 1, 15, 13, 15, true)
})

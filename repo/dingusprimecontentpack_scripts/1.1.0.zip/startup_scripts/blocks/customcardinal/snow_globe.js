onEvent('block.registry', event => {
	event.create('snow_globe', 'customcardinal').displayName('Snow Globe').material('wood').defaultCutout().notSolid().noValidSpawns(true).suffocating(false).viewBlocking(false).redstoneConductor(false).box(3, 0, 3, 13, 1, 13, true).box(3.5, 1, 3.5, 12.5, 10, 12.5, true).box(4, 0.5, 4, 12, 1.5, 12, true).box(9, 1.5, 8, 10, 2.5, 9, true).box(9.1, 2.5, 8.1, 9.9, 3.3, 8.9, true).box(9.2, 3.3, 8.2, 9.8, 3.9, 8.8, true).box(9.1, 3.9, 8.1, 9.9, 4, 8.9, true).box(9.3, 4, 8.3, 9.7, 4.5, 8.7, true).box(8.8, 3.4, 8.45, 9.2, 3.5, 8.55, true)
})

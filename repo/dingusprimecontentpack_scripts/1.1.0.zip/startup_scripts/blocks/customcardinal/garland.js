onEvent('block.registry', event => {
	event.create('garland', 'customcardinal').displayName('Garland').material('wood').defaultCutout().notSolid().noValidSpawns(true).suffocating(false).viewBlocking(false).redstoneConductor(false)
})

onEvent('block.registry', event => {
	event.create('candy_cane_red', 'customcardinal').displayName('Candy Cane Red').material('vegetable').defaultCutout().notSolid().noValidSpawns(true).suffocating(false).viewBlocking(false).redstoneConductor(false).box(4, 0, 7, 6, 11, 9, true).box(4, 11, 7, 5, 12, 9, true).box(6, 10, 7, 7, 11, 9, true).box(9, 10, 7, 10, 11, 9, true).box(11, 11, 7, 12, 12, 9, true).box(5, 11, 7, 11, 13, 9, true).box(10, 7, 7, 12, 11, 9, true)
})

onEvent('block.registry', event => {
	event.create('fancywooltoppedtable', 'customcardinal').displayName('Fancy Wool Topped Table').material('wood').defaultCutout().noValidSpawns(false).suffocating(false).viewBlocking(false).redstoneConductor(true).box(0, 14, 0, 16, 16, 16, true).box(1, 0, 1, 3, 14, 3, true).box(13, 0, 1, 15, 14, 3, true).box(1, 0, 13, 3, 14, 15, true).box(13, 0, 13, 15, 14, 15, true).box(2.5, 16, 0, 13.5, 16.1, 16, true).box(2.5, 14.72329, 16.15171, 13.5, 15.84829, 16.25171, true).box(2.5, 14.72329, -0.25171, 13.5, 15.84829, -0.15171, true)
})

onEvent('block.registry', event => {
	event.create('gingerbread_house', 'customcardinal').displayName('Gingerbread House').material('wood').defaultCutout().notSolid().noValidSpawns(true).suffocating(false).viewBlocking(false).redstoneConductor(false).box(2, 0, 2, 3, 8, 14, true).box(6, 11, 2, 10, 12, 14, true).box(3, 0, 2, 13, 9, 14, true).box(4, 9, 2, 12, 10, 14, true).box(5, 10, 2, 11, 11, 14, true).box(6, 11, 2, 10, 12, 14, true).box(7, 12, 2, 9, 13, 14, true).box(13, 0, 2, 14, 8, 14, true).box(2, 8, 10, 5, 14, 13, true)
})

onEvent('block.registry', event => {
	event.create('present_wrapped_pink', 'basic').displayName('Present Wrapped Pink').material('wood').defaultCutout().notSolid().noValidSpawns(true).suffocating(false).viewBlocking(false).redstoneConductor(false)
})

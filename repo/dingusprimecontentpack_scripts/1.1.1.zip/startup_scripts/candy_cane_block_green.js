onEvent('block.registry', event => {
	event.create('candy_cane_block_green', 'basic').displayName('Candy Cane Block Green').material('vegetable').lightLevel(5).defaultCutout().notSolid().noValidSpawns(true).suffocating(false).viewBlocking(false).redstoneConductor(false)
})
